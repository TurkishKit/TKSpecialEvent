import UIKit
import PlaygroundSupport
/*:
 ## Konum Bilgisi 🗺
 Konum bilgisi postunuzun nerede olduğunu belirtir. Bu bilginin çok çarpıcı olmaması gerekir o yüzden kullanıcı adından daha küçüktür ve bold değildir.
 
 İlk olarak bir *konumLabel* tanımlayıp onun büyüklüğünü ayarlayınız.
 */
let konumLabel = TKLabel(position: (0, 0))
/*:
 Oluşturduğunuz *konumLabel*'ın içine lokasyonunuzu belirtip yazının boyutlarını ayarlayınız.
 */
konumLabel.text = "Workinton"
konumLabel.font = UIFont.systemFont(ofSize: 10.0)
//: [Kullanıcı Adı](@previous) | Sayfa 5 | [Seçenekler Butonu](@next)
