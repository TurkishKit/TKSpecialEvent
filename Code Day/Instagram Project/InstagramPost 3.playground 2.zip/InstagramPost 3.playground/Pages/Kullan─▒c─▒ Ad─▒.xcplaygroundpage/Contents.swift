import UIKit
import PlaygroundSupport
/*:
 ## Kullanıcı Adı 👤
 Kullanıcı adı, instagrama atılan postların hangi kullanıcıya ait olduğunu belirler.
 * Callout(Dikkat❗️):
 Kullanıcı adının ön plana çıkması için semi bold yazılması gerekir.
 
 Kullanıcı adı bir String olduğundan onu *kullaniciAdiLabel* elemanının içinde tanımlayabilirsiniz.
 
 Oluşturduğunuz *kullaniciAdiLabel*'ının boyutlarını belirlemek önemlidir çünkü eğer boyutlarını belirlemezseniz, içine yazacağınız yazı sığmayabilir.
 */
let kullaniciAdiLabel = TKLabel(position: (10, 12))
kullaniciAdiLabel.text = "turkishkit"
/*:
 Kullanıcı adınızı semi bold yapmak için fontunu değiştirmeniz gerekecektir.
 */

//: [Profil Fotoğrafı](@previous) | Sayfa 4 | [Konum Bilgisi](@next)


