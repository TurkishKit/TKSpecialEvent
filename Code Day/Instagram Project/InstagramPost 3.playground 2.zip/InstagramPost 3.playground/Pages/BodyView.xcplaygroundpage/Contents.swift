/*:
 ## Body View
 Body View, instagram postumuzun en çarpıcı sayfasıdır. Büyük bir kısmı fotoğraflardan oluşmaktadır ve aynı zamanda butonları bulundurmaktadır.
 
 ### Body View'un içindekiler
 * Fotoğraflar
 * Beğeni Butonu
 * Yorum Butonu
 * Gönder Butonu
 * Kaydet Butonu
 * Sayfa Kontrolü

[Header View'u Birleştirmek](@previous) | Sayfa 8 | [Fotoğraflar](@next)
*/
