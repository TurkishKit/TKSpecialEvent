/*:
 ## Footer View 📱
 Footer view, gönderinin en altındaki kısımdır. Bu kısımda fotoğraflarınız hakkında diğer kullanıcıların düşündüklerini görebilirsiniz.
 ### Footer View'un içindekiler
 * Beğeni Sayısı
 * Gönderi Yorumu
 * Bütün Yorumları Gör
 
 [Body View' u Birleştirme](@previous) | Sayfa 16 | [Beğeni Sayısı](@next)
*/
