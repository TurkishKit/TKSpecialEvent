import UIKit
import PlaygroundSupport
/*:
 ## Kaydet Butonu📂
 Kaydet butonu gönderiyi instagramdaki kaydedilenler kısmına kaydetmek için vardır. Sizin için önemli olan postları veya dönüp tekrar bakmak isteyeceklerinizi bu butona basarak kaydedebilirsiniz.
 
 Kaydet butonunu ilk olarak bir *TKButton*'unun içine yerleştirmeniz gerekecektir.
 Sonradan bu butonunun dolu olmayan resmini normal haline ayarlamalısınız.
*/
let kaydetButonu = TKButton(position: (0,0), size: (40,40))
kaydetButonu.normalImage = UIImage.lineBookmarkIcon

/*:
 Beğeni butonuna benzer bir şekilde, kaydet butonuna basıldığında içinin dolması gerekecektir. Bu yüzden butonu basılınca içi dolu olan fotoğrafı tanımlamanız gerekecektir.
 *Callout(Tip💡):
 Bunu animasyon ekleyerek yapabilirsiniz.
 */
kaydetButonu.selectedImage = UIImage.filledBookmarkIcon
kaydetButonu.isAnimated = true
//: [Gönder Butonu](@previous) | Sayfa 13 | [Sayfa Kontolü](@next)
