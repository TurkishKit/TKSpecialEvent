import UIKit
import PlaygroundSupport
/*:
 ## Seçenekler Butonu
 
 More butonu, postun sağ üst köşesindeki üç nokta olmak üzere postu şikayet etmeye, linkini kopyalamaya veya başka bir uygulama kullanarak paylaşmaya yarar.
 
 More butonunu bir *UIButton* olarak tanımlamanız gerekecektir. Bu, ona basılınca bilgisayarın yapılan hareketi algılamasını sağlamaktadır.
 
 * Callout(Dikkat❗️):
 More butonunu tanımlarken pozisyonunu ve büyüklüğünü ayarlamayı unutmayın!
 */
let seceneklerButonu = TKButton(position: (346, 18), size: (20, 20))
seceneklerButonu.normalImage = UIImage.moreIcon
/*:
 * Callout(Not🖋):
 *UIImage* kısmındaki *for* ifadesi, butonun içine yerleştirdiğiniz resmin ne zaman gözüktüğünü belirtmektedir. Mesela, *.normal* dediğinizde butonun normal, basılmamış halinde o resim gözükecek demektir.
 */
//: [Lokasyon](@previous) | Sayfa 6 | [Header View'u Birleştirmek](@next)
