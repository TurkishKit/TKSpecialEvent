/*:
 ## Sayfa Kontrolü 🚥
Instagrama birden fazla fotoğraf konunca, fotoğrafların altında üç tane nokta belirir. Bu noktlardan biri mavi olmak üzere size kaç tane post olduğunu ve hangi postu görüntülediğinizi belirtir.
 
 Sayfa kontrolünüzü *TKPageControl* olarak tanımlayıp pozisyonunu ve boyutunu ayarlayınız.
*/
let sayfaKontrolu = TKPageControl(position: (0,0), size: (40,40))

/*:
 Sayfa kontrolünüzde post sayınıza göre nokta sayınızı belirleyiniz.
 */
sayfaKontrolu.numberOfDots = 3
/*:
 Noktalardan biri mavi olunca bu, hangi fotoğrafta olduğunuzu belirtir. Noktanın mavi haline o noktanın *aktif* olduğu hal olarak diyebilirsiniz.
 
 Aktif ve aktif olmayan noktaların renklerini belirleyiniz.
 */
sayfaKontrolu.activeDotColor = .instaBlue
sayfaKontrolu.inactiveDotColor = .instaLightGray

//: [Kaydet Butonu](@previous) | Sayfa 14 | [Body View'u Birleştirmek](@next)
