import Foundation
import UIKit

public let begeniSayisi = 38
public let gonderiYorumuLabel = "Burada, sizlerle olmak harika! #tkozeletkinligi"
public let yorumSayisi = 21
