import PlaygroundSupport
import UIKit
/*:
 ## Instagram Sayfası 📱
 Bütün viewları oluşturdunuz! Şimdi hepsini bir araya getirerek bir instagram sayfası yapabilirsiniz.😄
 
 Unutmadan instagram sayfanızda bulunanları kısa bir şekilde aklınızdan geçiriniz...
 * Callout(HeaderView):
 Profil fotoğrafı, kullanıcı adı, lokasyon, more butonu
 */
/*:
 * Callout(BodyView):
 Fotoğraflar, beğen butonu, yorum butonu, gönderme butonu, kaydet butonu
 */
/*:
 * Callout(FooterView):
 Beğeni sayısı, gönderi yorumu, butün yorumları gör
 
 Bütün View'ları bir araya toplayacağınız bir post View'u oluşturunuz. Bu View'un pozisyonunu ve boyutunu ayarlayınız.
 */

let postunBoyutu = (375.0, 560.0)
let instagramPostu = TKView(position: (0, 0), size: postunBoyutu)
/*:
 *instagramPostu* View'unun içine bütün View'larınızı yerleştiriniz.
 */
instagramPostu.addSubview(headerView)
instagramPostu.addSubview(bodyView)
instagramPostu.addSubview(footerView)

PlaygroundPage.current.liveView = instagramPostu
//:[Footer View'u Birleştirme](@previous) | Sayfa 21 | [Oturum Sonu](@next)
