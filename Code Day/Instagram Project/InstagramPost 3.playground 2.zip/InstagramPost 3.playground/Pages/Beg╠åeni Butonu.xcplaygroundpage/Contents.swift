import UIKit
import PlaygroundSupport
/*:
 ## Beğeni Butonu ♥️
 Beğeni butonu fotoğrafların altında bulunmaktadır bir fotoğrafı beğenip beğenmediğinizi belirlemektedir. Butona basıldığında kalbin içi renk değiştirir ve beğendiğinizi belli eder.
 
 Beğeni butonunu kodlamak için ilk olarak bir *UIButton* ve onun pozisyonunu tanımlamanız gerekecetir.
*/
let begeniButonu = TKButton(position: (0,0), size: (40,40))
begeniButonu.normalImage = UIImage.lineHeartIcon
/*:
 Bu butona basıldığında renginin değişmesini kodlayınız.
 */
begeniButonu.selectedImage = UIImage.filledHeartIcon
/*:
 İçi boş halden içi dolu hale geçmek için animasyon eklemeniz gerekecektir.
 */
begeniButonu.isAnimated = true
//: [Fotoğraflar](@previous) | Sayfa 10 | [Yorum Butonu](@next)
