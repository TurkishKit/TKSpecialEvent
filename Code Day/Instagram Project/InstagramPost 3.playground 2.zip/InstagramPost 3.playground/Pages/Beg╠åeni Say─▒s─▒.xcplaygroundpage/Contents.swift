import UIKit
import PlaygroundSupport
/*:
 # Footer View
 ## Beğeni Sayısı ♥️
 Bu sayı postunuzun kaç kişi tarafından beğenildiğini gösterir.
 * Callout(Dikkat❗️):
 Beğeni sayısı, beğeni butonuna bastığınızda bir artmalıdır.
 
 İlk olarak bir begenme sayisini tutacağınız bir *begenmeSayisi* değişkeni tanımlayınız
 */
let begenmeSayisi = 38

/*:
 Sonradan bu sayıyı *TKLabel* içine tanımlayınız.
 */
let begeniSayisiLabel = TKLabel(position: (0,0), size: (80,40))
/*:
 Beğeni sayısını Label'ın içinde görmek için Label'ın yazısını değiştiriniz.
 */
begeniSayisiLabel.text = "\(begenmeSayisi) likes"
/*:
 * Callout(Dikkat❗️):
 Beğeni sayısı Footer View'da çarpıcı bir kısımdır. Bu yüzden *beğeniSayısıLabel*'ını bold yapmanız gerekir.
 */
begeniSayisiLabel.changeFont(size: 14.0, style: .semibold, color: .black)

//: [Footer View](@previous) | Sayfa 17 | [Gönderi Yorumu](@next)
